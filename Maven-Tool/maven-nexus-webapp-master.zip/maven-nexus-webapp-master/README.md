# README #

This README helps you get started with setting up a maven web application, where maven generated artifacts can be pushed into Nexus

### What is this repository for? ###

* Setting up a maven web project 
* Pushing generated artifacts to nexus

